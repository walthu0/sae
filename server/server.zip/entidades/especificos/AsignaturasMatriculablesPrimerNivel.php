<?php
class AsignaturasMatriculablesPrimerNivel
{
   public $asignaturas;
   
   function __construct($asignaturas){
      $this->asignaturas = $asignaturas;
   }
}
?>